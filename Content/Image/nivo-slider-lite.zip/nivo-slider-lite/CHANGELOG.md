
 ### v2.3.0 - 2019-03-08 
 **Changes:** 
 * Tested up with WordPress 5.1
* Fix escaping attribute issue
* Remove mention of the pro plugin, discontinue integration on the Premium addon
 
 ### v2.2.0 - 2018-11-19 
 **Changes:** 
 * Improve compatibility with Wordpress 5.0 + Gutenberg Editor. 
* Adds integration with  Optimole - Image optimization service.
 
 ### v2.1.2 - 2018-05-28 
 **Changes:** 
 * Removes redundant files present in distribution.
* Sync ThemeIsle SDK code.
 
 ### v2.1.1 - 2018-01-05 
 **Changes:** 
 * Adds compatibility with latest WordPress standards.
* Sync ThemeIsle SDK.
 
 ### v2.1.0 - 2017-06-26 
 **Changes:** 
 * Added carousel compatibility
* Fixed warnings with taxonomy name change.
* Added upsell page.
 
 ### v2.0.4 - 2017-05-12 
 **Changes:** 
 - Changed required core style loading
 
 ### v2.0.3 - 2017-05-10 
 **Changes:** 
 - Small changes to .js for better integration with Shop-Isle-Pro
- Fixes height calculations.
 
 ### v2.0.2 - 2017-05-06 
 **Changes:** 
 - Removed redundant code.
 ### v2.0.1 - 2017-05-02

**Changes:**

- Fixed an issue with style loading for other post types.

### v2.0.0 - 2017-04-28  

**Changes:** 
 
- Added more slider themes.
- Added responsive option.
- Added more transition effects.
- Major code refactor.
 
### 3.0.0 - 17/02/2017

**Changes:**

- Refactored code base

### 2.5.1 - 12/12/2016

**Changes:** 

- added backward compat for license


### 2.5.0 - 21/11/2016

**Changes:** 

- Added plugin to themeisle system


### 2.5.0 - 21/11/2016

**Changes:** 

- Added plugin into themeisle system
